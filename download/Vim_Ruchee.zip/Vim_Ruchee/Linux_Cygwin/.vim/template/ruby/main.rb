#!/usr/bin/env ruby
# encoding: utf-8
