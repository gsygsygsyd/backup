﻿-----------------------------------------

vimrc配置文件     =>  http://www.ruchee.com/code/tools/vim/vimrc.shtml

Vimwiki入门       =>  http://www.ruchee.com/code/tools/vim/vimwiki_primer.html

snipMate配置      =>  http://www.ruchee.com/code/tools/vim/snipMate.html

snipMate补全文件  =>  http://www.ruchee.com/download/snipMate_Ruchee.zip

Vim配置及教程     =>  http://www.ruchee.com/download/Vim_Ruchee.zip

-----------------------------------------

以上链接永久有效，往后的更新将全部以上述链接发布

以前的旧链接，如vim/2011-05-18.html、download/Gvim_Ruby_2012-03-19.7z、download/Vim2012-04-01.7z、download/Vim2012-05-01.7z等不再提供访问支持

-----------------------------------------

下面描述的以及提供下载的配置文件均是我本机实际使用的配置信息，不再顾及大众需要（抱歉哈:)）

如有特殊需要，譬如想添加C++、Java、Python单源文件编译/运行支持的，请照猫画虎自行为之，不难，很简单

-----------------------------------------

功能描述：

01、支持常规的语法高亮、代码缩进、每行80个字符提示
02、支持括号、引号自动匹配
03、支持单源文件一键编译、运行 [已配置支持C/C++、Bash、Ruby]
04、支持一键载入语法模板
05、集成snipMate，支持tab键补全 [已完整配置支持的语种有C/C++、Ruby、HTML/JS]
06、集成zencoding，支持网页的快速编码
07、集成minibufexpl、NERD_tree、taglist等常规插件，便于开发工程级项目
08、支持GTK+和Qt4语法高亮
09、集成Powerline，支持状态栏彩色显示
10、支持ctags函数跳转 [需安装有ctags才能使用]

-----------------------------------------

更多功能请自行查看Vim配置文件 [Windows下路径为GVIM_HOME\_vimrc，Linux下路径为 ~/.vimrc]

zencoding简易的使用说明：http://www.ruchee.com/code/tools/vim/zencoding.html

snipMate支持的补全关键字，请自行查看GVIM_HOME\vimfiles\snippets [Linux下为~/.vim/snippets] 目录下的各个文件，你也可以自行修改和配置

下面是配置的具体使用方法，分Windows和Linux（Ubuntu与Cygwin）两个版本 [我使用的是Win7 + Xubuntu 12.04]

-----------------------------------------

Windows下的安装方法：

01、访问http://www.vim.org/download.php#pc下载最新的gVim

02、安装gVim到任意目录，这儿为方便讲解，我假定你安装到了C:\Apps\Vim\

03、将C:\Apps\Vim\vim73目录加入环境变量 [不知何为环境变量者，请Google]

04、删除Vim安装目录下的vimfiles目录

05、复制提供的vimfiles目录到C:\Apps\Vim下，取代已删目录的位置

06、将提供的小工具软件全部复制到C:\Apps\Vim\vim73目录下

07、复制_vimrc到C:\Apps\Vim进行替换

08、复制Monaco.ttf到C:\WINDOWS\Fonts目录下进行字体的安装

09、使用任意文本编辑器打开_vimrc，将名字、邮箱、网址等全部替换为你自己的信息，如遇路径不同也全部替换为你本机的实际路径

10、然后。。。然后就大功告成了，接下只需学习如何使用而已，使用说明全部集中在_vimrc文件的头部

-----------------------------------------

Ubuntu和Cygwin下的安装方法：

01、请确认已安装Vim，这儿不提供Vim的安装指导，如有需要请Google

02、删除家目录的.vim文件夹和.vimrc文件，如果没有则不需要执行删除动作 [使用命令 rm -rf .vim .vimrc]

03、复制Linux_Cygwin目录下的所有文件到家目录 [在解压后的Linux_Cygwin文件夹上打开终端，然后执行命令 cp -r . ~]

04、使用任意文本编辑器打开.vimrc，将名字、邮箱、网址等全部替换为你自己的信息，如遇路径不同也全部替换为你本机的实际路径

05、如此这般就配置好了，主要插件及快捷键的使用说明全部集中在.vimrc文件的头部

-----------------------------------------

ctags简易的使用说明，这儿仅以Ubuntu下的C++/Boost库为例

01、首先确保系统已安装ctags [使用命令 which ctags 检测是否已安装]

02、打开终端，转到/usr/include/boost目录 [使用命令 cd /usr/include/boost]

03、执行命令生成tags文件 sudo ctags -R --languages=c,c++ [生成的文件很大，所需时间也很长]

04、再次执行命令给tags文件设置合适的权限 sudo chmod 777 tags

05、在.vimrc文件中添加一行 set tags+=/usr/include/boost/tags

06、以后编辑C/C++源文件时，键入一小部分字符，然后按Ctrl + P即可拥有Boost的代码提示

07、将光标移到某个函数名上，按Ctrl + ]，Vim将自动跳转到该函数的定义，按Ctrl + T返回

由于/usr/include/boost目录下头文件过多，导致函数跳转的精确度不高，所以这个功能并不好用

如果只是需要补全，并不需要函数跳转功能的话，使用如下配置效果更好：
set path+=/usr/include/boost/

ctags更多的是用于生成当前工程的tags文件，以便各工程文件能互相跳转、查找

这儿只是讲解了ctags的一般性使用方法，对其他编程语言的使用也是类似的，更专业的介绍请求助Google

-----------------------------------------

Study_files目录提供了几份实用的Vim教程和图解，希望能给你学习Vim的使用带来帮助

附件下载地址：http://www.ruchee.com/download/Vim_Ruchee.zip

PS: 本压缩包是在Win7环境下使用Haozip生成的，在Linux下解压或将乱码，敬请注意

附件和配置文件将不定期更新，需要者请关注本文开头的各个链接


最后祝看到本文的IT同仁使用愉快！:)

-----------------------------------------

  Author: Ruchee
   Email: my@ruchee.com
 WebSite: http://www.ruchee.com
    Date: 2013-02-13
